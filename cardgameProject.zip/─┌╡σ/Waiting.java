package project;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class Waiting extends Frame implements ActionListener {
	JPanel panel, panel2;
	GridBagLayout gbl;
	ImageIcon image;
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	JScrollPane room, chatting, wait;
	JList<String> jList1, jList2;
	JTextArea jta;
	JTextField chattf;
	JButton send, createroom, exit, enter;
	Login login;
	Socket socket;
	String ip;
	String nickname;
	String id;
	String title;
	String selectbang, selectnum;
	static final int PORT = 5000;
	ObjectOutputStream oos;
	ObjectInputStream ois;
	Card2 card2;
	int k = -1;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public JTextArea getJta() {
		return jta;
	}

	public void setJta(JTextArea jta) {
		this.jta = jta;
	}

	public JTextField getChattf() {
		return chattf;
	}

	public void setChattf(JTextField chattf) {
		this.chattf = chattf;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Waiting(String id, String nickname, String ip) { 
		this.id = id;
		this.nickname = nickname;
		this.ip = ip;
		this.setTitle("����");
		image = new ImageIcon("d:\\waiting.jpg");
		panel = new JPanel(gbl = new GridBagLayout()) {

			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				g.drawImage(image.getImage(), 0, 0, getWidth(), getHeight(), null);
				setOpaque(false);
			}
		};
		this.add(panel);
		chattingPro();

		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
		this.setSize(1400, 800);
		this.setLocation((screenSize.width - this.getWidth()) / 2, 
				(screenSize.height - this.getHeight()) / 2);
		this.setVisible(true);
	}

	public void gbinsert(Component c, int x, int y, int w, int h) {
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.insets = new Insets(5, 5, 5, 5);
		gbc.gridx = x;
		gbc.gridy = y;
		gbc.gridwidth = w;
		gbc.gridheight = h;
		gbl.setConstraints(c, gbc);

		panel.add(c);
	}

	public void chattingPro() {
		room = new JScrollPane(jList1 = new JList<String>());
		room.setPreferredSize(new Dimension(600, 300));
		room.setBorder(new TitledBorder("�� ����"));
		jList1.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				String str = jList1.getSelectedValue();
				if (str.equals(null)) {
					return;
				}
				selectbang = str.substring(0, str.indexOf("("));
				selectnum = str.substring(str.indexOf(":") + 1, str.indexOf(")"));
			}

		});
		chatting = new JScrollPane(jta = new JTextArea(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		chatting.setPreferredSize(new Dimension(600, 300));
		jta.setEditable(false);
		chattf = new JTextField();
		chattf.addActionListener(this);
		chattf.setPreferredSize(new Dimension(500, 10));
		send = new JButton("������");
		send.addActionListener(this);
		wait = new JScrollPane(jList2 = new JList<String>());
		wait.setPreferredSize(new Dimension(400, 300));
		wait.setBorder(new TitledBorder("���� ����"));
		createroom = new JButton("�游���");
		createroom.setPreferredSize(new Dimension(200, 10));
		createroom.addActionListener(this);
		enter = new JButton("�������ϱ�");
		enter.setPreferredSize(new Dimension(200, 10));
		enter.addActionListener(this);
		exit = new JButton("������");
		exit.addActionListener(this);
		exit.setPreferredSize(new Dimension(200, 10));

		gbinsert(room, 0, 0, 5, 1);
		gbinsert(chatting, 0, 1, 5, 1);
		gbinsert(chattf, 0, 2, 3, 1);
		gbinsert(wait, 5, 0, 3, 2);
		gbinsert(send, 3, 2, 2, 1);
		gbinsert(createroom, 5, 2, 1, 1);
		gbinsert(enter, 6, 2, 1, 1);
		gbinsert(exit, 7, 2, 1, 1);
	}

	public void connect() {
		try {
			socket = new Socket(ip, PORT);
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());
			ClientThread ct = new ClientThread(this);
			ct.start();
			oos.writeObject("nickname" + "#" + nickname);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			if (e.getActionCommand().equals("�游���")) {
				title = JOptionPane.showInputDialog(this, "�������� �Է��Ͻÿ�.");
				if (title.length() == 0) {
					JOptionPane.showMessageDialog(this, "�������� �Է��Ͻÿ�.");
					return;
				}
				setVisible(false);
				card2 = new Card2(this);
				card2.setTitle(title);
				oos.writeObject("title" + "#" + title);
			}

			if (chattf.getText().length() != 0) { 

				String message = chattf.getText();
				if (message.trim().length() > 0) {
					oos.writeObject("allChat" + "#" + message);
				}

				chattf.setText("");
			}
			
			
			
			if (e.getActionCommand() == "������") { 

				oos.writeObject("allOut" + "#" + nickname);
				dispose();

			}
			
			if (e.getSource() == enter) {
				if (selectbang == null) {
					JOptionPane.showMessageDialog(this, "���� �����Ͻʽÿ�.");
					return;
				}
				if (selectnum.equals("2")) {
					JOptionPane.showMessageDialog(this, "������ �ʰ��߽��ϴ�.(2Play)");
					return;
				}
				setVisible(false);
				card2 = new Card2(this);
				oos.writeObject("enter" + "#" + selectbang);
			}

		} catch (Exception e2) {
			e2.getStackTrace();
		}
	}

	public class Card2 extends JFrame implements ActionListener {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		ImageIcon image, image2;
		JPanel panel, cardpanel, panel2;
		GridBagLayout gbl;
		JButton[] cardbutton = new JButton[28];
		int[] cards = new int[28];
		int[] cardnumber = new int[28];
		Random ran = new Random();
		ImageIcon[] cardimage = new ImageIcon[28];
		int cnt = 0;
		int[] cntlist = new int[2];
		Card2Thread c2t;
		Card22Thread c22t;
		CardBack cb;
		Thread t1;
		Thread t2;
		Thread t3;
		JLabel time, score;
		JTextArea timeta, scoreta, chatta;
		JButton start, send, exit;
		JScrollPane chatting;
		JTextField chattf;
		int startnum = 0;
		int jumsu = 0;
		ObjectOutputStream oos;
		ObjectInputStream ois;
		Waiting waiting;
		Socket socket;
		int cardcnt = 0;
		int cardplay = 0;
		int startnum2 = 0;
		boolean isflag = false;

		public Card2(Waiting waiting) {
			this.waiting = waiting;

			image = new ImageIcon("d:\\card.png");
			image2 = new ImageIcon("d:\\cardback.jpg");
			panel = new JPanel(gbl = new GridBagLayout()) {

				@Override
				protected void paintComponent(Graphics g) {
					// TODO Auto-generated method stub
					g.drawImage(image.getImage(), 0, 0, getWidth(), getHeight(), null);
					setOpaque(false);
				}
			};
			this.add(panel);
			initPro();
			cardSetImage();
			this.addWindowListener(new WindowAdapter() {

				@Override
				public void windowClosing(WindowEvent e) {
					// TODO Auto-generated method stub
					dispose();
				}
			});
			this.setSize(1400, 800);
			this.setLocation((screenSize.width - this.getWidth()) / 2, (screenSize.height - this.getHeight()) / 2);
			this.setVisible(true);

		}

		public void gbinsert(Component c, int x, int y, int w, int h) {
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.fill = GridBagConstraints.BOTH;
			gbc.insets = new Insets(5, 5, 5, 5);
			gbc.gridx = x;
			gbc.gridy = y;
			gbc.gridwidth = w;
			gbc.gridheight = h;
			gbl.setConstraints(c, gbc);

			panel.add(c);
		}

		public void cardSetImage() {
			cardpanel = new JPanel(new GridLayout(4, 7, 5, 7)) {

				@Override
				protected void paintComponent(Graphics g) {
					// TODO Auto-generated method stub
					g.drawImage(image.getImage(), 0, 0, getWidth(), getHeight(), null);
					setOpaque(false);
				}
			};

			for (int i = 0; i < cardbutton.length; i++) {
				cardbutton[i] = new JButton(image2);
				cardbutton[i].setPreferredSize(new Dimension(100, 150));
				cardbutton[i].addActionListener(this);
				cardpanel.add(cardbutton[i]);
			}
			gbinsert(cardpanel, 0, 1, 5, 3);
		}

		public void initPro() {
			time = new JLabel("���� �ð�");
			time.setForeground(Color.WHITE);
			time.setFont(new Font("����", Font.BOLD, 15));
			timeta = new JTextArea(1, 7);
			timeta.setEditable(false);
			score = new JLabel("����");
			score.setForeground(Color.WHITE);
			score.setFont(new Font("����", Font.BOLD, 15));
			scoreta = new JTextArea(1, 7);
			scoreta.setEditable(false);
			start = new JButton("START");
			start.addActionListener(this);
			start.setPreferredSize(new Dimension(200, 100));
			chatting = new JScrollPane(chatta = new JTextArea(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			chatting.setPreferredSize(new Dimension(300, 500));
			chatta.setEditable(false);
			chattf = new JTextField();
			chattf.setPreferredSize(new Dimension(190, 25));
			send = new JButton("������");
			send.addActionListener(this);
			exit = new JButton("������");
			exit.addActionListener(this);

			gbinsert(time, 0, 0, 1, 1);
			gbinsert(timeta, 1, 0, 1, 1);
			gbinsert(score, 2, 0, 1, 1);
			gbinsert(scoreta, 3, 0, 1, 1);
			gbinsert(start, 5, 3, 1, 1);
			gbinsert(exit, 6, 3, 1, 1);
			gbinsert(chatting, 5, 1, 2, 1);
			gbinsert(chattf, 5, 2, 1, 1);
			gbinsert(send, 6, 2, 1, 1);
		}

		public void gamePlay() {

			for (int i = 0; i < cardbutton.length; i++) {
				cardimage[i] = new ImageIcon(Toolkit.getDefaultToolkit().getImage("d:\\" + cards[i] + ".jpg")
						.getScaledInstance(100, 150, Image.SCALE_SMOOTH));
				cardbutton[i].setIcon(cardimage[i]);
				cardnumber[i] = cards[i];
			}
			cb = new CardBack(waiting);
			t3 = new Thread(cb);
			t3.start();
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			for (int i = 0; i < cardbutton.length; i++) {
				if (e.getSource() == cardbutton[i] && startnum == 1) {
					if (cnt < 2) {
						cardbutton[i].setIcon(cardimage[i]);
						cntlist[cnt] = cards[i];
						try {
							waiting.oos.writeObject("cardnumber" + "#" + cntlist[cnt]);
						} catch (Exception e2) {
							// TODO: handle exception
							e2.printStackTrace();
						}
						cnt++;
					}
				}
			}
			compareCard();

			if (e.getActionCommand().equals("START")) {
				if (cardplay == 0) {
					try {
						waiting.oos.writeObject("start" + "#" + waiting.nickname);
						start.setEnabled(false);
					} catch (Exception e2) {
						e2.getStackTrace();
					}
				} else {
					try {
						waiting.oos.writeObject("start2" + "#" + waiting.title);
						start.setEnabled(false);
						jumsu = 0;
						cnt = 0;
					} catch (Exception e2) {
						e2.getStackTrace();
					}
				}
			}

			if (chattf.getText().length() != 0) {
				try {
					String message = chattf.getText();
					if (message.trim().length() > 0) {
						waiting.oos.writeObject("cardChat" + "#" + waiting.nickname + "#" + message);
					}
				} catch (Exception e2) {
					e2.getStackTrace();
				}
				chattf.setText("");
			}

			if (e.getActionCommand().equals("������")) {
				try {
					waiting.oos.writeObject("cardExit" + "#" + waiting.nickname);
					this.setVisible(false);
					waiting.setVisible(true);
				} catch (Exception e2) {
					e2.getStackTrace();
				}
			}
		}

		public synchronized void compareCard() {
			if (cnt == 2) {
				System.out.println("���ϱ�");

				if (cntlist[0] == cntlist[1]) { // ���� ī�� ���ý� cnt--
					cnt--;
					return;
				}

				if (cntlist[0] < 14) {
					if ((cntlist[0] + 14) == cntlist[1]) {
						System.out.println("����!!!");
						cnt = 0;
						jumsu += 50;
						try {
							waiting.oos.writeObject("cardCnt" + "#" + waiting.nickname);
							waiting.oos.writeObject("timeRun" + "#" + waiting.nickname);
							if (cardcnt == 13) {
								waiting.oos.writeObject("startbutton" + "#" + waiting.title); // start��ư �ٽ� Ȱ��ȭ
								cardplay++;

								if (waiting.card2.jumsu > 350) {
									waiting.oos
											.writeObject("result" + "#" + waiting.nickname + "#" + waiting.card2.jumsu);

								}
								if (waiting.card2.jumsu == 350) {
									waiting.oos.writeObject(
											"result1" + "#" + waiting.nickname + "#" + waiting.card2.jumsu);

								}
								if (waiting.card2.jumsu < 350) {
									waiting.oos.writeObject(
											"result2" + "#" + waiting.nickname + "#" + waiting.card2.jumsu);
								}
							}
						} catch (Exception e) {
							// TODO: handle exception
						}
					} else {
						System.out.println("�ٸ���");
						c22t = new Card22Thread(waiting);
						t2 = new Thread(c22t);
						t2.start();
						try {

							waiting.oos.writeObject("turn" + "#" + waiting.nickname);

						} catch (Exception e) {
							// TODO: handle exception
							e.getStackTrace();
						}
					}
				} else if (cntlist[0] >= 14) {
					if ((cntlist[0] - 14) == cntlist[1]) {
						System.out.println("����!!!");
						cnt = 0;
						jumsu += 50;
						try {
							waiting.oos.writeObject("timeRun" + "#" + waiting.nickname);
							waiting.oos.writeObject("cardCnt" + "#" + waiting.nickname);
							if (cardcnt == 13) {
								waiting.oos.writeObject("startbutton" + "#" + waiting.title); // start��ư �ٽ� Ȱ��ȭ
								cardplay++;

								if (waiting.card2.jumsu > 350) {
									waiting.oos
											.writeObject("result" + "#" + waiting.nickname + "#" + waiting.card2.jumsu);
								}
								if (waiting.card2.jumsu == 350) {
									waiting.oos.writeObject(
											"result1" + "#" + waiting.nickname + "#" + waiting.card2.jumsu);

								}
								if (waiting.card2.jumsu < 350) {
									waiting.oos.writeObject(
											"result2" + "#" + waiting.nickname + "#" + waiting.card2.jumsu);
								}
							}
						} catch (Exception e) {
							// TODO: handle exception
						}
					} else {
						System.out.println("�ٸ���");
						c2t = new Card2Thread(waiting);
						t1 = new Thread(c2t);
						t1.start();
						try {

							waiting.oos.writeObject("turn" + "#" + waiting.nickname);

						} catch (Exception e) {
							// TODO: handle exception
							e.getStackTrace();
						}

					}
				}
			}
		}

	}
}
