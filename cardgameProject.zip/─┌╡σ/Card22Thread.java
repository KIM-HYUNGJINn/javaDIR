package project;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Card22Thread implements Runnable{
	Waiting waiting;
	Socket socket;
	ObjectOutputStream oos;
	ObjectInputStream ois;
	
	public Card22Thread(Waiting waiting) {
		super();
		this.waiting = waiting;
		try {
			socket = new Socket(waiting.card2.waiting.ip, waiting.card2.waiting.PORT);
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());
		} catch (Exception e) {
			// TODO: handle exception
			e.getStackTrace();
		}
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(2000);
			int i = 0;
			for (i = 0; i < waiting.card2.cardnumber.length; i++) {
				if ((waiting.card2.cardnumber[i] == waiting.card2.cntlist[0]) || (waiting.card2.cardnumber[i] == waiting.card2.cntlist[1])) {
					waiting.card2.cardbutton[i].setIcon(waiting.card2.image2);
				}
				waiting.oos.writeObject("reset"+"#"+waiting.card2.cntlist[i]);
			}
		} catch (Exception e) {
			e.getStackTrace();
		}
	}
}
