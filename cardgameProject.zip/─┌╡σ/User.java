package project;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Random;
import java.util.Vector;

public class User extends Thread {
	Socket socket;

	Room room;
	Vector<User> allV;
	Vector<User> waitV;
	Vector<Room> roomV;
	int getready;

	ObjectInputStream ois;
	ObjectOutputStream oos;

	String nickname = null;
	Random random = new Random();
	int[] cards = new int[28];

	public User(Socket s, Server server) {
		this.socket = socket;
		allV = server.allV;
		waitV = server.waitV;
		roomV = server.roomV;

		try {
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());

			start();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		boolean isStop = false;
		String message = null;
		try {
			while (!isStop) {
				message = (String) ois.readObject();
				System.out.println(message);
				if (message == null) {
					return;
				}

				String[] str = message.split("#");
				String protocol = str[0];

				switch (protocol) {

				case "nickname":
					allV.add(this); // ��ü����� ���
					waitV.add(this); // ������� ���

					nickname = str[1]; // �г��� �Է�

					if(!getRoomInfo().equals(""))
						messageWait("infor" + "#" + getRoomInfo()); // ������
					messageWait("wait" + "#" + getWaitInwon()); // ����
					break;

				case "allChat": 
					messageAll("allChat" + "#" + nickname + "#" + str[1]);
					break;

				case "allOut": // �ƿ� ������
					messageAll("allOut" + "#" + str[1]);

					waitV.remove(this);
					allV.remove(this);
					
					messageWait("infor" + "#" + getRoomInfo()); // ������
					messageWait("wait" + "#" + getWaitInwon()); // ����

					break;

				case "title": 
					room = new Room();
					room.title = str[1];
					room.count = 1;
					room.bangjang = nickname;
					room.player = null;
					room.getready = 0;

					waitV.remove(this);
					roomV.add(room);
					room.userV.add(this);

					messageRoom("entrance" + "#" + nickname); 
					messageWait("infor" + "#" + getRoomInfo()); 
					messageWait("wait" + "#" + getWaitInwon()); 
					break;

				case "enter":
					for (int i = 0; i < roomV.size(); i++) {
						Room rr = roomV.get(i);
						if (rr.title.equals(str[1])) {
							room = rr;
							room.count++;
							this.room.player = nickname;
							break;
						}
					}
					messageTo("bangtitle" + "#" + room.title);
					waitV.remove(this);
					room.userV.add(this);
					messageRoom("entrance" + "#" + nickname);
					messageAll("infor" + "#" + getRoomInfo());	
					messageWait("wait" + "#" + getWaitInwon()); 
					break;

				case "cardChat":
					messageRoom("cardChat" + "#" + str[1] + "#" + str[2]);

					break;

				case "cardExit":
					messageRoom("cardExit" + "#" + str[1]);

					room.count--;
					room.userV.remove(this);
					waitV.add(this);

					if (room.count == 0) {
						roomV.remove(this);
					}
					
					messageWait("infor" + "#" + getRoomInfo()); // ������
					messageWait("wait" + "#" + getWaitInwon()); // ����

					break;

				case "start":
					for (int i = 0; i < roomV.size(); i++) {
						Room room = roomV.get(i);
						if (room.bangjang.equals(str[1]) || room.player.equals(str[1])) {
							this.room = room;
							this.room.getready += 1;
							break;
						}
					}
					if (room.getready == 2) {
						messageRoom("gamestart1" + "#" + room.bangjang);
						messageRoom("gamestart2" + "#" + random());
					}

					break;

				case "cardnumber":
					messageRoom("cardnumber" + "#" + str[1]);

					break;

				case "reset":
					messageRoom("reset" + "#" + str[1]);

					break;

				case "turn":
					messageRoom(message);
					break;

				case "timeRun":
					messageRoom(message);
					break;

				case "result":
					messageRoom(message);
					break;

				case "result1":
					messageRoom(message);
					break;

				case "result2":
					messageRoom(message);
					break;

				case "cardCnt":
					System.out.println("�������� ī��Ʈ�޾Ҵ�");
					messageRoom(message);
					break;

				case "startbutton":
					// messageRoom(message);
					for (int i = 0; i < roomV.size(); i++) {
						Room rr = roomV.get(i);

						if (rr.title.equals(str[1])) {
							room = rr;
							room.getready = 0;
							break;
						}
					}
					messageRoom(message);
					break;

				case "start2":
					for (int i = 0; i < roomV.size(); i++) {
						Room rr = roomV.get(i);

						if (rr.title.equals(str[1])) {
							room.getready += 1;
							break;
						}
					}
					if (room.getready == 2) {
						messageRoom("gamestart1" + "#" + room.bangjang);
						messageRoom("gamestart2" + "#" + random());
					}
					break;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public String getRoomInfo() {
		String str = "";
		for (int i = 0; i < roomV.size(); i++) { 
			Room room = roomV.get(i);
			str += room.title + "(���ο�:" + room.count + ")";
			if (i < roomV.size() - 1) {
				str += ",";
			}
			if(room.count == 0) {
				str = "";
			}
		}		
		return str;
	}
	public String getWaitInwon() {
		String str = "";
		for (int i = 0; i < waitV.size(); i++) { 
			User user = waitV.get(i);
			str += user.nickname;
			if (i < waitV.size() - 1) {
				str += ",";
			}
		}
		return str;
	}
	public void messageWait(String message) {
		for (int i = 0; i < waitV.size(); i++) {
			User user = waitV.get(i); 
			try {
				user.messageTo(message); 
			} catch (Exception e) {
				waitV.remove(i--);
			}
		}
	}

	
	
	public void messageAll(String message) {
		for (int i = 0; i < allV.size(); i++) {
			User user = allV.get(i);
			try {
				user.messageTo(message);
			} catch (Exception e) {
				allV.remove(i--);
				System.out.println("Ŭ���̾�Ʈ ���� ����!!");
			}
		}
	}

	
	public void messageRoom(String message) {
		for (int i = 0; i < room.userV.size(); i++) {
			User user = room.userV.get(i);
			try {
				user.messageTo(message);
			} catch (Exception e) {
				room.userV.remove(i--);
				System.out.println("Ŭ���̾�Ʈ�� ������ ������ϴ�.");
			}
		}
	}

	public String random() {
		String str = "";

		for (int i = 0; i < cards.length; i++) {
			cards[i] = random.nextInt(28);
			for (int j = 0; j < i; j++) {
				if (cards[i] == cards[j]) {
					i--;
					break;
				}
			}
		}
		for (int i = 0; i < cards.length; i++) {
			str += cards[i];
			if (i < cards.length - 1) {
				str += ",";
			}
		}
		return str;
	}

	public void messageTo(String message) {
		try {
			oos.writeObject(message);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
 }









