package project;

import java.io.ObjectInputStream;
import java.util.stream.IntStream;

public class ClientThread extends Thread {
	Waiting waiting;
	String nickname;

	public ClientThread(Waiting waiting) {
		super();

		this.waiting = waiting;
		nickname = waiting.nickname;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		boolean isStop = false;
		String message = null;

		while (!isStop) {
			try {
				message = (String) waiting.ois.readObject();
				System.out.println("Client: "+message);
				String[] str = message.split("#");
				String protocol = str[0];

				switch (protocol) {
				case "wait": // �����
					String[] waitnickname = str[1].split(",");
					waiting.jList2.setListData(waitnickname);
					break;
					

				case "infor": // ��
					int nCount =0;
					if (str.length > 1) {
						String[] bangname = str[1].split(",");
						String[] strTemp = new String[bangname.length];
						
						for(int i=0; i<bangname.length;i++) {
							if(!bangname[i].endsWith("0)")){
								strTemp[nCount++] = bangname[i];
							}
						}
						waiting.jList1.setListData(strTemp);
						//waiting.jList1.setListData(bangname);
					}
					break;

				case "bangtitle": 
					waiting.card2.setTitle(str[1]);
					break;

				case "entrance": 
					waiting.card2.chatta.append(str[1] + "���� �����ϼ̽��ϴ�." + System.getProperty("line.separator"));
					waiting.card2.chatta.setCaretPosition(waiting.card2.chatta.getDocument().getLength());
					break;

				case "allChat":
					waiting.jta.append(str[1] + "-->" + str[2] + System.getProperty("line.separator"));
					waiting.jta.setCaretPosition(waiting.jta.getDocument().getLength());
					break;
					
				case "allOut":
					waiting.jta.append("==========[" + str[1] + "]���� �����ϼ̽��ϴ�.=========="+ System.getProperty("line.separator"));
					waiting.jta.setCaretPosition(waiting.jta.getDocument().getLength());
					break;

				case "gamestart1":
					if (waiting.nickname.equals(str[1])) {
						waiting.card2.startnum += 1;
					} else {
						waiting.card2.startnum = 0;
					}
					break;

				case "gamestart2":
					String[] random = str[1].split(",");
					for (int i = 0; i < random.length; i++) {
						waiting.card2.cards[i] = Integer.parseInt(random[i]);
					}
					waiting.card2.gamePlay();
					break;

				case "cardnumber":
					int i = 0;
					for (i = 0; i < waiting.card2.cardnumber.length; i++) {
						if (waiting.card2.cardnumber[i] == Integer.parseInt(str[1])) {
							waiting.card2.cardbutton[i].setIcon(waiting.card2.cardimage[i]);
						}
					}
					break;
					
				case "reset":
					int j=0;
					for(j=0 ; j<waiting.card2.cardnumber.length;j++) {
						if(waiting.card2.cardnumber[j] == Integer.parseInt(str[1])) {
							waiting.card2.cardbutton[j].setIcon(waiting.card2.image2);
						}
					}
					
					break;

				case "cardChat":
					waiting.card2.chatta.append(str[1] + "-->" + str[2] + System.getProperty("line.separator"));
					waiting.card2.chatta.setCaretPosition(waiting.card2.chatta.getDocument().getLength());
					
					break;

				case "cardExit":
					waiting.card2.chatta.append("==========[" + str[1] + "]���� �����ϼ̽��ϴ�.=========="+ System.getProperty("line.separator"));
					waiting.card2.chatta.setCaretPosition(waiting.card2.chatta.getDocument().getLength());
					break;
					
				case "turn":
					if (waiting.nickname.equals(str[1]) && waiting.card2.startnum==1) {
						waiting.card2.startnum = 0;
						waiting.card2.cnt=0;
						waiting.card2.cb.nCount = 0;
					} else {
						waiting.card2.startnum = 1;
						waiting.card2.cnt=0;
						waiting.card2.cb.nCount = 0;
					}
					
					break;
											
				case "timeRun":
					if (waiting.nickname.equals(str[1])){
						waiting.card2.cb.nCount=0;
					}else {
						waiting.card2.cb.nCount=0;
					}

					break;
					
				case "result":
					System.out.println("���ӳ� Ŭ�󽺷��� �޾Ҵ�.");
					if(waiting.nickname.equals(str[1])&& waiting.card2.startnum==1) {
						waiting.card2.chatta.append("==========�¸��ϼ̽��ϴ�.=========="+ System.getProperty("line.separator"));
						waiting.card2.chatta.setCaretPosition(waiting.card2.chatta.getDocument().getLength());
						waiting.card2.cb.isFlag=false;
						waiting.card2.isflag=true;
						waiting.card2.startnum=0;
					}else {
						waiting.card2.chatta.append("==========�й��ϼ̽��ϴ�.=========="+ System.getProperty("line.separator"));
						waiting.card2.chatta.setCaretPosition(waiting.card2.chatta.getDocument().getLength());
						waiting.card2.cb.isFlag=false;
						waiting.card2.isflag=true;
						waiting.card2.startnum=0;
					}		
					break;
				case "result1":
					if (waiting.nickname.equals(str[1])){
						waiting.card2.chatta.append("==========�����Դϴ�.=========="+ System.getProperty("line.separator"));
						waiting.card2.chatta.setCaretPosition(waiting.card2.chatta.getDocument().getLength());
						waiting.card2.cb.isFlag=false;
						waiting.card2.isflag=true;
						waiting.card2.startnum=0;
					}
					else {
						waiting.card2.chatta.append("==========�����Դϴ�.=========="+ System.getProperty("line.separator"));
						waiting.card2.chatta.setCaretPosition(waiting.card2.chatta.getDocument().getLength());
						waiting.card2.cb.isFlag=false;
						waiting.card2.isflag=true;
						waiting.card2.startnum=0;
					}
						break;
				case "result2":
					System.out.println("���ӳ� Ŭ�󽺷��� �޾Ҵ�.");
					if(waiting.nickname.equals(str[1])&& waiting.card2.startnum==1) {
						waiting.card2.chatta.append("==========�й��ϼ̽��ϴ�.=========="+ System.getProperty("line.separator"));
						waiting.card2.chatta.setCaretPosition(waiting.card2.chatta.getDocument().getLength());
						waiting.card2.cb.isFlag=false;
						waiting.card2.isflag=true;
						waiting.card2.startnum=0;
					}else {
						waiting.card2.chatta.append("==========�¸��ϼ̽��ϴ�.=========="+ System.getProperty("line.separator"));
						waiting.card2.chatta.setCaretPosition(waiting.card2.chatta.getDocument().getLength());
						waiting.card2.cb.isFlag=false;
						waiting.card2.isflag=true;
						waiting.card2.startnum=0;
					}		
					break;
				case "cardCnt":
					System.out.println("ī��ī��Ʈ Ŭ�󿡼�����"+String.valueOf(waiting.card2.cardcnt));
					if(waiting.nickname.equals(str[1])&&waiting.card2.startnum==1 ) {
					waiting.card2.cardcnt+=1;
				}else {
				
					waiting.card2.cardcnt+=1;
					
				}
					break;
					
				case "startbutton":
					waiting.card2.start.setEnabled(true);
					break;
				}
                
			} catch (Exception e) {
				// TODO: handle exception
				
				e.printStackTrace();
			}
		}
	}

}