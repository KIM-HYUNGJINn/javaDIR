package project;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class Server implements Runnable{
	static final int PORT = 5000;
	Vector<User> allV;	//��� �����
	Vector<User> waitV;	//���� �����
	Vector<Room> roomV; //ī���
   
    
	public Server() {
		allV = new Vector<>();
		waitV = new Vector<>();
		roomV = new Vector<>();
		
		Thread t = new Thread(this);
		t.start();
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		boolean isStop = false;
		
		try {
			ServerSocket serverSocket = new ServerSocket(PORT);
			System.out.println("Server is Start");
			
			while(!isStop) {
				Socket socket = serverSocket.accept();
				User user = new User(socket, this);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new Server();
	}
	
}
