package project;

public class CardBack extends Thread {
	Waiting waiting;
	int time = 16;
	int nCount = 0;
	boolean isFlag = true;
	public CardBack(Waiting waiting) {
		super();
		this.waiting = waiting;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(3000);

			for (int i = 0; i < waiting.card2.cardbutton.length; i++) {
				
				waiting.card2.cardbutton[waiting.card2.cards[i]].setIcon(waiting.card2.image2);
			}
			
			while(isFlag) {
				Thread.sleep(1000);
                if(nCount<=16) {  
				nCount++;
                }
				waiting.card2.timeta.setText(String.valueOf(time-nCount)+"��");
				waiting.card2.scoreta.setText(String.valueOf(waiting.card2.jumsu)+"��");
				if(time==nCount) {
					int i = 0;
					if(waiting.card2.cnt==1) {
					for (i = 0; i < waiting.card2.cardnumber.length; i++) {
						if ((waiting.card2.cardnumber[i] == waiting.card2.cntlist[0])) {
							waiting.card2.cardbutton[i].setIcon(waiting.card2.image2);
						}
					}
					nCount=0;
					waiting.oos.writeObject("reset"+"#"+waiting.card2.cntlist[0]);
					}
					if(waiting.nickname.equals(waiting.nickname)&& waiting.card2.startnum==1) {
						nCount=0;
						waiting.oos.writeObject("turn"+"#"+waiting.nickname);
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.getStackTrace();
		}

	}
}
