package project;

import java.util.Vector;

public class Room {
	String title;
	int count;
	String bangjang;	//����
	String player;	//�÷��̾�
	Vector<User> userV;
	int getready;
	
	public Room() {
		userV = new Vector<>();
	}

}
