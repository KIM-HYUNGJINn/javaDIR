package project;

import java.io.Serializable;

import javax.swing.table.AbstractTableModel;

public class Information implements Serializable {
	String name;
	String nickname;
	String id;
	String gender;
	Integer birthyear;
	Integer birthmonth;
	Integer birthdate;
	String password;
	public Information() {
		super();
		
	}
	public Information(String name, String nickname, String id, String gender, Integer birthyear, Integer birthmonth,
			Integer birthdate, String password) {
		super();
		this.name = name;
		this.nickname = nickname;
		this.id = id;
		this.gender = gender;
		this.birthyear = birthyear;
		this.birthmonth = birthmonth;
		this.birthdate = birthdate;
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Information [name=" + name + ", nickname=" + nickname + ", id=" + id +  ", password="
				+ password + "]";
	}
}
